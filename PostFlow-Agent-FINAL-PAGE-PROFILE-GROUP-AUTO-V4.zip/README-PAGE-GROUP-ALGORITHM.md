# PostFlow Agent - Page -> Group Discovery Algorithm

## Mục tiêu

Khi Facebook đã đăng nhập trên Chrome mobile và Agent nhận diện người dùng đang ở ngữ cảnh một Facebook Page, Agent thu thập:

1. Tên Page.
2. Page ID nếu Facebook/Chrome thực sự expose ID trong Accessibility tree hoặc URL/href.
3. Danh sách Group của chính Page, không phải danh sách Group cá nhân của tài khoản.

## Nguyên tắc

- Không đọc mật khẩu, cookie, local storage hoặc Chrome profile.
- Không dùng cookie/session token để gọi Facebook.
- Không coi một link `/groups/...` xuất hiện ngẫu nhiên trong feed là Group của Page.
- Không fallback mù sang menu Groups của tài khoản cá nhân.
- Chỉ ghi nhận Group sau khi Agent đã vào một Page Groups context được xác thực.

## State machine

```text
PAGE DETECTED
    |
    v
COLLECT CURRENT TREE
    |
    +--> Page-specific Groups control?
    |        |
    |        +--> click
    |        |
    |        v
    |    VERIFY DESTINATION
    |
    +--> hidden behind More/See more?
             |
             +--> click More
             |
             +--> search Page-specific Groups again

VERIFIED PAGE GROUPS
    |
    v
HARVEST VISIBLE GROUP CARDS
    |
    v
SCROLL ALL SCROLLABLE CONTAINERS
    |
    v
DEDUP BY URL OR NORMALIZED NAME
    |
    v
3 consecutive no-progress passes + no scroll
    |
    v
BACK TO PAGE
    |
    v
SYNC TO PANEL
```

## Chống nhầm Group cá nhân

Selector ưu tiên:

- Nhóm của Trang
- Groups of this Page
- Page Groups
- Groups for this Page
- Groups managed by this Page
- Groups this Page joined
- Page communities

Generic `Groups/Nhóm` chỉ được phép click nếu clickable subtree đồng thời chứa tên Page hiện tại.

Sau khi click, Agent xác thực:

- có tín hiệu Groups;
- nếu selector là generic thì phải còn Page name hoặc Group URL trong context;
- selector Page-specific được xem là bằng chứng mạnh hơn vì Facebook có thể không lặp lại Page name ở heading mới.

## Thu thập Group

Ưu tiên URL thật:

```text
https://facebook.com/groups/...
```

Nếu Chrome không expose href nhưng Accessibility tree expose tên card Group, Agent lưu:

```json
{"url":"","name":"Tên Group"}
```

Không tự tạo URL giả.

## Lazy loading

Agent chạy tối đa 80 pass. Mỗi pass:

1. đọc Accessibility tree;
2. thêm Group mới;
3. đồng bộ incremental;
4. scroll container;
5. tạo fingerprint của tree.

Chỉ kết thúc khi có 3 pass liên tiếp không thêm Group mới và không còn scroll được.

## Page ID

Agent chỉ lưu Page ID khi ID được expose bằng một trong các nguồn thật:

- text `Page ID`, `ID Page`, `ID Trang`;
- URL `/pages/<name>/<numeric_id>`;
- query `?id=<numeric_id>` hoặc `?page_id=<numeric_id>`;
- href tương ứng được Accessibility tree expose.

Nếu Facebook chỉ expose tên Page và URL dạng `facebook.com/ten-page`, Agent không đoán Page ID từ tên.


## V3 critical fixes

- Facebook context is now gated by the current Chrome window URL/strong Facebook UI signals. The PostFlow Panel opened in Chrome can no longer be misread as a Facebook Page.
- Page identity is tracked separately from a generic occurrence of the word Page.
- Generic Groups/Nhóm candidates are only considered after a strong Page identity signal.
- Page-specific and generic Group selectors are scored separately so a personal Groups shortcut is not preferred over a Page-specific control.
