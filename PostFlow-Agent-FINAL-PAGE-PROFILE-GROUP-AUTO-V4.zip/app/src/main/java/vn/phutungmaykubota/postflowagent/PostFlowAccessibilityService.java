package vn.phutungmaykubota.postflowagent;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.List;
import java.util.Locale;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.regex.Pattern;

/**
 * PostFlow Agent - Chrome/Facebook detector.
 *
 * Important:
 * - Only Chrome/Facebook application packages are accepted as foreground state.
 * - IME/launcher/other app events NEVER overwrite Chrome state.
 * - For Chrome, only the omnibox URL node is inspected.
 */
public class PostFlowAccessibilityService extends AccessibilityService {

    public static volatile boolean isRunning = false;
    public static volatile String lastPackage = "";
    public static volatile String lastUrl = "";
    public static volatile boolean facebookDetected = false;
    public static volatile long lastEventTime = 0L;
    public static volatile long lastChromeTime = 0L;
    public static volatile boolean pageDetected = false;
    public static volatile String pageName = "";
    public static volatile String pageUrl = "";
    public static volatile String pageId = "";
    public static volatile String facebookMode = "UNKNOWN";
    public static volatile String visibleGroupsJson = "[]";
    private static final String PREF_LAST_PAGE_NAME = "last_page_name";

    private static final String CHROME = "com.android.chrome";
    private static final String FACEBOOK = "com.facebook.katana";
    private static final String FACEBOOK_LITE = "com.facebook.lite";

    private static final long STATE_TIMEOUT_MS = 24 * 60 * 60 * 1000L;
    // Keep Facebook detection sticky while the user switches Chrome tabs.
    // A new Chrome session is considered only after a long absence, so a
    // normal tab switch/backgrounding does not erase Facebook state.
    private static final long CHROME_SESSION_GAP_MS = 30 * 60 * 1000L;
    private volatile boolean facebookSeenInChromeSession = false;
    private volatile long chromeSessionStartedAt = 0L;
    private static final long URL_PROBE_INTERVAL_MS = 2500L;
    private static final String PREFS = "postflow_agent_final";
    private static final String PREF_LAST_PAGE_URL = "last_page_url";
    private static final String PREF_LAST_PAGE_ID = "last_page_id";

    private volatile long lastUrlProbeAt = 0L;
    private volatile long lastGroupDiscoveryAt = 0L;
    private volatile boolean groupDiscoveryRunning = false;
    private volatile boolean pageContextAnnounced = false;
    private volatile boolean pageIdentityStrong = false;
    private volatile boolean groupContextTrusted = false;
    private volatile boolean groupContextWasPageSpecific = false;
    // Which Facebook identity owns the group list currently being discovered.
    // PAGE = groups joined/linked to the active Page; PROFILE = groups joined
    // by the personal Facebook account.
    private volatile String groupDiscoveryOwner = "";
    private volatile int groupDiscoveryPass = 0;
    private volatile int groupDiscoveryNoProgress = 0;
    private volatile String lastGroupTreeSignature = "";
    private final LinkedHashMap<String,String> discoveredGroups = new LinkedHashMap<>();

    private static final Pattern FACEBOOK_URL = Pattern.compile(
            "(?i)^(?:https?://)?(?:www\\.)?(?:[a-z0-9-]+\\.)*facebook\\.com(?:[/:?#].*)?$"
    );

    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;
            refreshChromeFromActiveWindow();
            expireStaleState();
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable heartbeat = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;

            new Thread(new Runnable() {
                @Override
                public void run() {
                    AgentSync.heartbeat(PostFlowAccessibilityService.this);
                }
            }, "PostFlowHeartbeat").start();

            handler.postDelayed(this, 5000);
        }
    };

    private final Runnable commandPoller = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;

            new Thread(new Runnable() {
                @Override
                public void run() {
                    AgentCommand.pollAndExecute(PostFlowAccessibilityService.this);
                }
            }, "PostFlowCommandPoll").start();

            handler.postDelayed(this, 5000);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();

        try {
            android.accessibilityservice.AccessibilityServiceInfo info = getServiceInfo();
            if (info != null) {
                info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                        | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                        | AccessibilityEvent.TYPE_VIEW_FOCUSED
                        | AccessibilityEvent.TYPE_WINDOWS_CHANGED;
                info.feedbackType = android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_GENERIC;
                info.flags = android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                        | android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
                        | android.accessibilityservice.AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;
                info.notificationTimeout = 300;
                setServiceInfo(info);
            }
        } catch (Throwable ignored) {
        }

        isRunning = true;
        lastEventTime = System.currentTimeMillis();

        handler.removeCallbacks(poller);
        handler.removeCallbacks(heartbeat);
        handler.removeCallbacks(commandPoller);

        handler.post(poller);
        handler.post(heartbeat);
        handler.post(commandPoller);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        // Android can deliver an event immediately while the service is
        // reconnecting. Treat that event as proof that the service is alive.
        isRunning = true;
        lastEventTime = System.currentTimeMillis();

        String pkg = event.getPackageName() == null
                ? ""
                : event.getPackageName().toString();

        /*
         * CRITICAL:
         * Do NOT call a generic foreground-window detector first.
         * Android may report Launcher/IME/LabanKey while Chrome remains
         * the visible browser. Such events must never erase Chrome state.
         */
        if (CHROME.equals(pkg)) {
            markChrome(event);
            return;
        }

        if (FACEBOOK.equals(pkg) || FACEBOOK_LITE.equals(pkg)) {
            lastPackage = pkg;
            facebookDetected = true;
            lastUrl = "";
            lastChromeTime = System.currentTimeMillis();
            return;
        }

        /*
         * Ignore Launcher, keyboard, System UI and every unrelated package.
         * This is the key fix for the previous "com.android.launcher3" bug.
         */
        expireStaleState();
    }

    private void beginOrKeepChromeSession(long now) {
        if (chromeSessionStartedAt == 0L
                || (lastChromeTime > 0L && now - lastChromeTime > CHROME_SESSION_GAP_MS)) {
            chromeSessionStartedAt = now;
            facebookSeenInChromeSession = false;
            facebookDetected = false;
            pageDetected = false;
            pageName = "";
            pageUrl = "";
            pageId = "";
            facebookMode = "UNKNOWN";
        }
    }

    private void markChrome(AccessibilityEvent event) {
        long now = System.currentTimeMillis();

        beginOrKeepChromeSession(now);
        lastPackage = CHROME;
        lastChromeTime = now;

        AccessibilityNodeInfo source = null;

        try {
            source = event.getSource();

            if (source != null) {
                String url = findChromeUrlBar(source);
                if (!url.isEmpty()) updateChromeUrl(url);
                inspectFacebookContext(source);
                return;
            }
        } catch (Throwable ignored) {
        } finally {
            if (source != null) {
                try {
                    source.recycle();
                } catch (Throwable ignored) {
                }
            }
        }

        /*
         * Event is definitely from Chrome even if Chrome temporarily hides
         * or rebuilds the URL bar. Keep Chrome alive and keep the last known
         * Facebook URL instead of replacing it with Launcher/IME.
         */
        facebookDetected = facebookDetected && isFacebookUrl(lastUrl);
    }

    /**
     * Poll Chrome's actual active application window.
     * This is only used to refresh Chrome state, never to replace it with
     * Launcher/IME/another app.
     */
    private void refreshChromeFromActiveWindow() {
        if (!isRunning) return;

        AccessibilityNodeInfo root = null;

        try {
            root = getRootInActiveWindow();

            // IMPORTANT: getRootInActiveWindow() can temporarily return null
            // on Android/Chrome mobile. Do NOT return here. We must still
            // inspect AccessibilityWindowInfo below, otherwise Chrome is
            // reported as "not detected" even while it is on screen.
            if (root != null) {
                CharSequence p = root.getPackageName();
                String pkg = p == null ? "" : p.toString();

                if (CHROME.equals(pkg)) {
                    long now = System.currentTimeMillis();
                    beginOrKeepChromeSession(now);
                    lastPackage = CHROME;
                    lastChromeTime = now;
                    String url = findChromeUrlBar(root);
                    if (!url.isEmpty()) updateChromeUrl(url);
                    inspectFacebookContext(root);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (root != null) {
                try {
                    root.recycle();
                } catch (Throwable ignored) {
                }
            }
        }

        // ALWAYS inspect accessibility windows. This is the fallback for
        // Chrome builds where getRootInActiveWindow() is null or stale.
        refreshChromeFromWindows();
    }

    private void refreshChromeFromWindows() {
        List<AccessibilityWindowInfo> windows;

        try {
            windows = getWindows();
        } catch (Throwable ignored) {
            return;
        }

        if (windows == null) return;

        // Chrome may expose the omnibox as the focused window while the
        // Facebook document is exposed by another Chrome accessibility
        // window.  Inspect ALL Chrome application windows for Facebook/Page
        // context, but only an active/focused Chrome window is allowed to
        // establish that Chrome itself is online.
        boolean chromeWindowFound = false;
        for (AccessibilityWindowInfo window : windows) {
            if (window == null || window.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
            AccessibilityNodeInfo r = null;
            try {
                r = window.getRoot();
                if (r == null || !CHROME.equals(packageName(r))) continue;
                chromeWindowFound = true;
                long now = System.currentTimeMillis();
                if (window.isActive() || window.isFocused()) {
                    beginOrKeepChromeSession(now);
                    lastPackage = CHROME;
                    lastChromeTime = now;
                }
                // Always inspect Chrome's document tree. The current URL is
                // read first so a non-Facebook tab cannot masquerade as a
                // Facebook Page merely because the Panel itself contains the
                // words Facebook/Page/Group.
                String url = findChromeUrlBar(r);
                if (!url.isEmpty() && (window.isActive() || window.isFocused())) {
                    updateChromeUrl(url);
                }
                inspectFacebookContext(r);
            } catch (Throwable ignored) {
            } finally {
                if (r != null) try { r.recycle(); } catch (Throwable ignored) {}
            }
        }

        if (!chromeWindowFound) return;
        return;

        /* old single-window implementation intentionally removed */
        /*
        for (AccessibilityWindowInfo window : new AccessibilityWindowInfo[]{best}) {
            if (window == null) continue;

            AccessibilityNodeInfo root = null;

            try {
                root = window.getRoot();
                if (root == null) continue;

                CharSequence p = root.getPackageName();
                String pkg = p == null ? "" : p.toString();

                if (!CHROME.equals(pkg)) continue;

                long now = System.currentTimeMillis();
                beginOrKeepChromeSession(now);
                lastPackage = CHROME;
                lastChromeTime = now;
                inspectFacebookContext(root);

                String url = findChromeUrlBar(root);
                if (!url.isEmpty()) {
                    updateChromeUrl(url);
                    return;
                }
            } catch (Throwable ignored) {
            } finally {
                if (root != null) {
                    try {
                        root.recycle();
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
    }

        */

    /**
     * Only search for Chrome's omnibox resource id.
     * We never recursively read arbitrary Facebook page text.
     */
    /**
     * Chrome Android can display only "facebook.com" in the omnibox even
     * when the real tab URL contains /pages/... or /groups/....  The
     * accessibility tree may expose only the shortened display value while
     * the URL bar is not focused.  When that happens, briefly focus/copy the
     * URL-bar value and read the clipboard.  We accept the clipboard only if
     * it is a specific Facebook URL, never passwords/cookies/page content.
     */
    private String packageName(AccessibilityNodeInfo node) {
        if (node == null || node.getPackageName() == null) return "";
        return node.getPackageName().toString();
    }

    private AccessibilityNodeInfo findChromeUrlBarNode(AccessibilityNodeInfo node) {
        if (node == null) return null;
        try {
            CharSequence id = node.getViewIdResourceName();
            if (id != null) {
                String resource = id.toString().toLowerCase(Locale.US);
                if (resource.contains("url_bar") || resource.endsWith(":id/url_bar")) {
                    return node;
                }
            }

            int count = node.getChildCount();
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child = null;
                try {
                    child = node.getChild(i);
                    AccessibilityNodeInfo found = findChromeUrlBarNode(child);
                    if (found != null) {
                        // Do not recycle a node returned to the caller.
                        child = null;
                        return found;
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (child != null) {
                        try { child.recycle(); } catch (Throwable ignored) {}
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private boolean isFacebookRootUrl(String value) {
        if (value == null) return false;
        String s = value.trim();
        return s.matches("(?i)^https?://(?:www\\.)?facebook\\.com/?$");
    }

    private boolean isSpecificFacebookUrl(String value) {
        if (value == null) return false;
        String s = value.trim();
        if (!isFacebookUrl(s) || isFacebookRootUrl(s)) return false;
        try {
            android.net.Uri uri = android.net.Uri.parse(s);
            String path = uri.getPath() == null ? "" : uri.getPath().trim();
            if (path.isEmpty() || "/".equals(path)) return false;
            String first = path.replaceFirst("^/", "").split("/", 2)[0].toLowerCase(Locale.US);
            return !first.isEmpty();
        } catch (Throwable ignored) {
            return false;
        }
    }

    private String findChromeUrlBar(AccessibilityNodeInfo node) {
        if (node == null) return "";

        try {
            CharSequence id = node.getViewIdResourceName();

            if (id != null) {
                String resource = id.toString().toLowerCase(Locale.US);

                if (resource.contains("url_bar") || resource.endsWith(":id/url_bar")) {
                    // IMPORTANT: On Chrome Android the visible text can be only
                    // "facebook.com" while contentDescription contains the full
                    // current URL (including /pages/... or other path).
                    // Prefer the full URL candidate so Panel follows navigation
                    // inside Facebook instead of staying at https://facebook.com.
                    String value = bestUrlCandidate(node);
                    if (!value.isEmpty()) return value;
                }
            }

            int count = node.getChildCount();
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child = null;
                try {
                    child = node.getChild(i);
                    if (child != null) {
                        String found = findChromeUrlBar(child);
                        if (!found.isEmpty()) return found;
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (child != null) {
                        try { child.recycle(); } catch (Throwable ignored) {}
                    }
                }
            }
        } catch (Throwable ignored) {
        }

        return "";
    }

    private String bestUrlCandidate(AccessibilityNodeInfo node) {
        String description = node.getContentDescription() == null
                ? "" : node.getContentDescription().toString().trim();
        String text = node.getText() == null
                ? "" : node.getText().toString().trim();
        String hint = node.getHintText() == null
                ? "" : node.getHintText().toString().trim();

        // 1) Prefer a complete http(s) URL from contentDescription.
        if (isCompleteHttpUrl(description)) return description;
        if (isCompleteHttpUrl(text)) return text;
        if (isCompleteHttpUrl(hint)) return hint;

        // 2) Then accept facebook.com/path from any exposed property.
        if (looksLikeUrlOrFacebook(description)) return description;
        if (looksLikeUrlOrFacebook(text)) return text;
        if (looksLikeUrlOrFacebook(hint)) return hint;

        return "";
    }

    private boolean isCompleteHttpUrl(String value) {
        if (value == null) return false;
        String s = value.trim();
        return s.matches("(?i)^https?://[^\\s]+$");
    }

    private String nodeValue(AccessibilityNodeInfo node) {
        String best = bestUrlCandidate(node);
        if (!best.isEmpty()) return best;
        return "";
    }

    private boolean looksLikeUrlOrFacebook(String value) {
        if (value == null) return false;

        String s = value.trim();

        if (s.isEmpty()) return false;

        return s.matches("(?i)^https?://.*")
                || s.matches("(?i)^(?:www\\.)?(?:[a-z0-9-]+\\.)*facebook\\.com(?:/.*)?$")
                || s.matches("(?i)^facebook\\.com(?:/.*)?$");
    }


    /**
     * Detect Facebook context from Chrome's accessibility tree, not from the
     * omnibox URL. Facebook mobile may keep the URL at facebook.com while the
     * user has switched into a Page context.
     */
    private void inspectFacebookContext(AccessibilityNodeInfo root) {
        if (root == null || !CHROME.equals(packageName(root))) return;

        // IMPORTANT: the PostFlow Panel is also opened in Chrome and contains
        // words such as "Facebook", "Page" and "Group".  Never interpret the
        // Panel as Facebook. Check the URL currently exposed by THIS Chrome
        // window or require several independent Facebook UI signals.
        String currentUrl = findChromeUrlBar(root);
        ArrayList<String> texts = new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collectUsefulNodes(root, texts, nodes, 0);

        boolean facebookDocument = isFacebookDocumentTree(texts, currentUrl);
        if (!facebookDocument) {
            for (AccessibilityNodeInfo n : nodes) {
                try { n.recycle(); } catch (Throwable ignored) {}
            }
            return;
        }

        String detectedName = "";
        int bestScore = 0;
        for (String t : texts) {
            String n = extractPageName(t);
            if (!n.isEmpty()) {
                int score = pageNameScore(t, n);
                if (score > bestScore) {
                    bestScore = score;
                    detectedName = n;
                }
            }
        }

        // Facebook mobile often keeps the omnibox at facebook.com when the
        // user has switched from a personal profile to a Page.  The Page
        // identity is therefore inferred from the Facebook UI itself.
        String inferredPageName = inferPageNameFromFacebookUi(texts);
        if (detectedName.isEmpty() && !inferredPageName.isEmpty()) {
            detectedName = inferredPageName;
            bestScore = Math.max(bestScore, 85);
        }

        pageIdentityStrong = hasStrongPageIdentitySignal(texts, inferredPageName, detectedName);
        boolean profileSignal = hasStrongPersonalIdentitySignal(texts);

        // Identity priority is deliberate: a strong Page identity wins, a
        // strong personal-profile identity wins otherwise. Generic words such
        // as "Page", "Groups" or "Profile" are never enough by themselves.
        boolean pageSignal = pageIdentityStrong && (bestScore >= 60
                || containsPageContextSignal(texts)
                || !inferredPageName.isEmpty());

        if (pageSignal) {
            boolean wasPage = pageDetected;
            pageDetected = true;
            facebookMode = "PAGE";

            String previousPageName = pageName == null ? "" : pageName;

            if (!detectedName.isEmpty()) {
                pageName = cleanUiText(detectedName);
                savePageName(pageName);
            } else if (pageName.isEmpty()) {
                pageName = getSavedPageName();
            }

            // A real Page switch must start a fresh Group discovery. The
            // previous implementation only discovered once per service
            // lifetime, so switching Page A -> Page B kept the old list.
            boolean pageChanged = !pageName.isEmpty()
                    && !pageName.equalsIgnoreCase(previousPageName);

            if (pageChanged) {
                discoveredGroups.clear();
                visibleGroupsJson = "[]";
                pageContextAnnounced = false;
                pageIdentityStrong = false;
                pageId = "";
                pageUrl = "";
                savePageId("");
                savePageUrl("");
                groupContextTrusted = false;
                groupContextWasPageSpecific = false;
                groupDiscoveryOwner = "";
                groupDiscoveryPass = 0;
                groupDiscoveryNoProgress = 0;
                lastGroupTreeSignature = "";
                lastGroupDiscoveryAt = 0L;
                pageIdentityStrong = hasStrongPageIdentitySignal(texts, inferredPageName, detectedName);
            }

            // Keep discovery automatic. It is triggered by the UI transition
            // to PAGE, never by the omnibox URL.
            if (!wasPage || !pageContextAnnounced || pageChanged || discoveredGroups.isEmpty()
                    || !groupDiscoveryOwner.equals("PAGE")) {
                if (!groupDiscoveryOwner.equals("PAGE")) {
                    groupDiscoveryRunning = false;
                    discoveredGroups.clear();
                    visibleGroupsJson = "[]";
                    groupContextTrusted = false;
                    groupContextWasPageSpecific = false;
                    groupDiscoveryPass = 0;
                    groupDiscoveryNoProgress = 0;
                    lastGroupTreeSignature = "";
                }
                pageContextAnnounced = true;
                groupDiscoveryOwner = "PAGE";
                scheduleAutomaticPageGroupDiscovery();
            }
        } else {
            // Facebook document detected but no strong Page identity is
            // visible. Treat the active identity as the personal account and
            // discover its Groups list. This is intentional: the Agent follows
            // the identity Facebook exposes, not a stale Page name saved earlier.
            // Do not keep a stale Page identity as the current identity.
            pageDetected = false;
            facebookMode = "PROFILE";
            pageIdentityStrong = false;

            boolean ownerChanged = !groupDiscoveryOwner.equals("PROFILE");
            if (ownerChanged) {
                groupDiscoveryRunning = false;
                // Never mix Page groups with personal-account groups.
                    discoveredGroups.clear();
                    visibleGroupsJson = "[]";
                    groupContextTrusted = false;
                    groupContextWasPageSpecific = false;
                    groupDiscoveryPass = 0;
                    groupDiscoveryNoProgress = 0;
                    lastGroupTreeSignature = "";
            }
            groupDiscoveryOwner = "PROFILE";
            pageName = "";
            pageId = "";
            pageUrl = "";
            if (ownerChanged || discoveredGroups.isEmpty()) {
                scheduleAutomaticProfileGroupDiscovery();
            }
        }

        String detectedPageId = pageDetected ? extractPageId(texts, lastUrl, pageUrl) : "";
        if (!detectedPageId.isEmpty()) {
            pageId = detectedPageId;
            savePageId(pageId);
        } else if (pageId.isEmpty()) {
            pageId = getSavedPageId();
        }

        // Only Page-Groups discovery is authoritative. A random /groups/...
        // link appearing in a Page feed is NOT evidence that the Page belongs
        // to that Group, so it is ignored unless we are inside the verified
        // Page Groups context.
        LinkedHashMap<String,String> groups = new LinkedHashMap<>(discoveredGroups);
        if (groupContextTrusted) {
            for (String t : texts) {
                String lower = t.toLowerCase(Locale.US);
                if (lower.contains("facebook.com/groups/")) {
                    String url = extractFacebookGroupUrl(t);
                    if (!url.isEmpty()) groups.put(url, "Facebook Group");
                }
            }
            for (AccessibilityNodeInfo n : nodes) {
                String desc = n.getContentDescription() == null ? "" : n.getContentDescription().toString();
                String txt = n.getText() == null ? "" : n.getText().toString();
                String combined = desc + " " + txt;
                String url = extractFacebookGroupUrl(combined);
                if (!url.isEmpty()) {
                    String name = cleanUiText(txt);
                    if (name.isEmpty()) name = cleanUiText(desc);
                    if (name.isEmpty()) name = "Facebook Group";
                    groups.put(url, name);
                }
            }
        }
        try {
            JSONArray arr = new JSONArray();
            for (Map.Entry<String,String> e : groups.entrySet()) {
                JSONObject o = new JSONObject();
                o.put("url", e.getKey());
                o.put("name", e.getValue());
                o.put("owner_type", groupDiscoveryOwner.isEmpty() ? "UNKNOWN" : groupDiscoveryOwner);
                if (pageDetected) o.put("page_name", pageName);
                arr.put(o);
            }
            visibleGroupsJson = arr.toString();
        } catch (Throwable ignored) {}

        for (AccessibilityNodeInfo n : nodes) {
            try { n.recycle(); } catch (Throwable ignored) {}
        }
    }

    /**
     * Automatically discover the Groups associated with the currently active
     * Facebook Page. The user only has to switch from Profile to Page.
     *
     * We never touch Chrome's omnibox and never use loadUrl(). The Agent only
     * uses accessibility actions on Facebook's own navigation controls.
     */
    private void scheduleAutomaticProfileGroupDiscovery() {
        long now = System.currentTimeMillis();
        if (!isRunning || !isChromeActive() || pageDetected) return;
        if (groupDiscoveryRunning) return;
        if (now - lastGroupDiscoveryAt < 5000L) return;

        lastGroupDiscoveryAt = now;
        groupDiscoveryRunning = true;
        groupDiscoveryOwner = "PROFILE";

        handler.postDelayed(new Runnable() {
            @Override public void run() {
                try {
                    autoOpenAndCollectProfileGroups(0);
                } catch (Throwable ignored) {
                    groupDiscoveryRunning = false;
                }
            }
        }, 500L);
    }

    private void scheduleAutomaticPageGroupDiscovery() {
        long now = System.currentTimeMillis();
        if (!pageDetected || !isChromeActive()) return;
        if (groupDiscoveryRunning) return;
        if (now - lastGroupDiscoveryAt < 12000L) return;

        lastGroupDiscoveryAt = now;
        groupDiscoveryRunning = true;
        groupDiscoveryOwner = "PAGE";

        handler.postDelayed(new Runnable() {
            @Override public void run() {
                try {
                    autoOpenAndCollectPageGroups(0);
                } catch (Throwable ignored) {
                    groupDiscoveryRunning = false;
                }
            }
        }, 700L);
    }

    /**
     * Automatic Page -> Groups discovery.
     *
     * The user does NOT have to open a Group.  The Agent may open the
     * Page's own Groups list through an Accessibility click, collect the
     * Group cards/links, then return to the Page.  No password, cookie,
     * WebView or Chrome storage is accessed.
     */
    /**
     * Page -> Groups discovery state machine.
     *
     * Rules:
     * 1) Never click the personal-account "Groups/Nhóm" destination merely
     *    because the word exists. A candidate must be Page-specific or be
     *    inside a subtree that also contains the current Page name.
     * 2) After a click, verify that the destination is a Page Groups context
     *    before harvesting names. This prevents importing the user's personal
     *    groups by mistake.
     * 3) Once inside a trusted Page Groups context, harvest visible cards,
     *    scroll every scrollable container, deduplicate, and stop only after
     *    three consecutive passes make no progress and no scroll action is
     *    possible.
     * 4) If Accessibility never exposes a Page Groups destination, do not
     *    invent a list. The Agent keeps the Page data and reports only groups
     *    actually exposed by the tree.
     */
    /**
     * Discover groups joined by the personal Facebook account. This is a
     * separate state machine from Page -> Groups so the Agent never mixes
     * personal membership with Page membership.
     */
    private void autoOpenAndCollectProfileGroups(final int attempt) {
        if (!isRunning || !isChromeActive() || pageDetected || !groupDiscoveryOwner.equals("PROFILE")) {
            groupDiscoveryRunning = false;
            return;
        }

        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            if (root == null || !CHROME.equals(packageName(root))) {
                if (attempt < 15) {
                    handler.postDelayed(() -> autoOpenAndCollectProfileGroups(attempt + 1), 700L);
                } else {
                    groupDiscoveryRunning = false;
                }
                return;
            }

            // If Facebook has already opened the global Groups/Your Groups
            // screen, trust this context because we entered it through the
            // personal-profile discovery path.
            if (groupContextTrusted && isProfileGroupsContext(root)) {
                groupDiscoveryPass = 0;
                groupDiscoveryNoProgress = 0;
                lastGroupTreeSignature = "";
                handler.postDelayed(() -> collectGroupsFromFacebookScreen(0), 500L);
                return;
            }

            // First look for explicit membership destinations. Generic
            // "Groups/Nhóm" is also allowed here because the active identity
            // has already been positively classified as the personal profile.
            AccessibilityNodeInfo target = findBestProfileGroupsTarget(root);
            if (target != null) {
                boolean clicked = false;
                try { clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK); }
                finally { try { target.recycle(); } catch (Throwable ignored) {} }

                if (clicked) {
                    groupContextTrusted = true;
                    groupContextWasPageSpecific = false;
                    groupDiscoveryOwner = "PROFILE";
                    groupDiscoveryPass = 0;
                    groupDiscoveryNoProgress = 0;
                    lastGroupTreeSignature = "";
                    handler.postDelayed(() -> collectGroupsFromFacebookScreen(0), 1300L);
                    return;
                }
            }

            // Groups is often hidden under More / Xem thêm. Open it and search
            // again on the next pass.
            AccessibilityNodeInfo more = findBestMoreTarget(root);
            if (more != null && attempt < 10) {
                try { more.performAction(AccessibilityNodeInfo.ACTION_CLICK); }
                finally { try { more.recycle(); } catch (Throwable ignored) {} }
                handler.postDelayed(() -> autoOpenAndCollectProfileGroups(attempt + 1), 800L);
                return;
            }

            if (attempt < 15) {
                handler.postDelayed(() -> autoOpenAndCollectProfileGroups(attempt + 1), 900L);
            } else {
                updateVisibleGroupsFromDiscovered();
                groupDiscoveryRunning = false;
            }
        } catch (Throwable ignored) {
            if (attempt < 15) {
                handler.postDelayed(() -> autoOpenAndCollectProfileGroups(attempt + 1), 900L);
            } else {
                groupDiscoveryRunning = false;
            }
        } finally {
            if (root != null) try { root.recycle(); } catch (Throwable ignored) {}
        }
    }

    private AccessibilityNodeInfo findBestProfileGroupsTarget(AccessibilityNodeInfo root) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> matches = new ArrayList<>();
        collectContainingNodes(root, matches, new String[]{
                "nhóm đã tham gia", "groups you've joined", "your groups",
                "nhóm của bạn", "groups you manage", "nhóm bạn quản lý",
                "groups", "nhóm", "group"
        }, 0);

        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MIN_VALUE;
        for (AccessibilityNodeInfo n : matches) {
            AccessibilityNodeInfo candidate = clickableSelfOrAncestor(n);
            if (candidate == null) continue;

            String t = n.getText() == null ? "" : cleanUiText(n.getText().toString()).toLowerCase(Locale.US);
            String d = n.getContentDescription() == null ? "" : cleanUiText(n.getContentDescription().toString()).toLowerCase(Locale.US);
            int score = 0;

            if (t.contains("nhóm đã tham gia") || d.contains("nhóm đã tham gia")
                    || t.contains("groups you've joined") || d.contains("groups you've joined")) score += 10000;
            else if (t.contains("your groups") || d.contains("your groups")
                    || t.contains("nhóm của bạn") || d.contains("nhóm của bạn")) score += 9000;
            else if (t.contains("groups you manage") || d.contains("groups you manage")
                    || t.contains("nhóm bạn quản lý") || d.contains("nhóm bạn quản lý")) score += 8000;
            else if (t.equals("groups") || d.equals("groups") || t.equals("nhóm") || d.equals("nhóm")) score += 5000;
            else if (t.equals("group") || d.equals("group")) score += 4500;
            else continue;

            try {
                android.graphics.Rect r = new android.graphics.Rect();
                candidate.getBoundsInScreen(r);
                score += Math.min(2000, Math.max(0, r.top));
            } catch (Throwable ignored) {}

            if (score > bestScore) {
                if (best != null) try { best.recycle(); } catch (Throwable ignored) {}
                best = candidate;
                bestScore = score;
            } else {
                try { candidate.recycle(); } catch (Throwable ignored) {}
            }
        }
        for (AccessibilityNodeInfo n : matches) try { n.recycle(); } catch (Throwable ignored) {}
        return best;
    }

    private boolean isProfileGroupsContext(AccessibilityNodeInfo root) {
        if (root == null || !groupContextTrusted || !groupDiscoveryOwner.equals("PROFILE")) return false;
        return isGroupsContext(root);
    }

    private void autoOpenAndCollectPageGroups(final int attempt) {
        if (!isRunning || !pageDetected || !isChromeActive() || !groupDiscoveryOwner.equals("PAGE")) {
            groupDiscoveryRunning = false;
            return;
        }

        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            if (root == null || !CHROME.equals(packageName(root))) {
                if (attempt < 15) {
                    handler.postDelayed(() -> autoOpenAndCollectPageGroups(attempt + 1), 700L);
                } else {
                    groupDiscoveryRunning = false;
                }
                return;
            }

            // First harvest anything already exposed on the Page screen.
            collectGroupEntriesFromTree(root);
            updateVisibleGroupsFromDiscovered();

            // If we are already in a verified Page Groups screen, do not click
            // another navigation item. Continue harvesting instead.
            if (groupContextTrusted && isPageGroupsContext(root)) {
                groupDiscoveryPass = 0;
                groupDiscoveryNoProgress = 0;
                lastGroupTreeSignature = "";
                handler.postDelayed(() -> collectGroupsFromFacebookScreen(0), 500L);
                return;
            }

            // Find only Page-specific candidates. Generic "Groups/Nhóm" is
            // deliberately rejected unless the same clickable subtree also
            // contains the current Page name.
            AccessibilityNodeInfo target = findBestPageGroupsTarget(root);
            if (target != null) {
                boolean clicked = false;
                try {
                    clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                } finally {
                    try { target.recycle(); } catch (Throwable ignored) {}
                }

                if (clicked) {
                    groupContextTrusted = true;
                    groupDiscoveryOwner = "PAGE";
                    groupDiscoveryPass = 0;
                    groupDiscoveryNoProgress = 0;
                    lastGroupTreeSignature = "";
                    handler.postDelayed(() -> collectGroupsFromFacebookScreen(0), 1500L);
                    return;
                }
            }

            // Page navigation is frequently hidden behind "See more / Xem
            // thêm". Open it, then re-run the Page-specific selector.
            AccessibilityNodeInfo more = findBestMoreTarget(root);
            if (more != null && attempt < 10) {
                try {
                    more.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                } finally {
                    try { more.recycle(); } catch (Throwable ignored) {}
                }
                handler.postDelayed(() -> autoOpenAndCollectPageGroups(attempt + 1), 900L);
                return;
            }

            if (attempt < 15) {
                handler.postDelayed(() -> autoOpenAndCollectPageGroups(attempt + 1), 900L);
            } else {
                // No Page Groups destination was exposed to Accessibility.
                // Do not fall back to personal-account Groups.
                updateVisibleGroupsFromDiscovered();
                groupDiscoveryRunning = false;
            }
        } catch (Throwable ignored) {
            if (attempt < 15) {
                handler.postDelayed(() -> autoOpenAndCollectPageGroups(attempt + 1), 900L);
            } else {
                groupDiscoveryRunning = false;
            }
        } finally {
            if (root != null) try { root.recycle(); } catch (Throwable ignored) {}
        }
    }

    private AccessibilityNodeInfo findBestPageGroupsTarget(AccessibilityNodeInfo root) {
        if (root == null) return null;

        ArrayList<AccessibilityNodeInfo> matches = new ArrayList<>();
        collectContainingNodes(root, matches, new String[]{
                "nhóm của trang", "groups of this page", "page groups",
                "groups for this page", "groups managed by this page",
                "nhóm mà trang tham gia", "groups this page joined",
                "groups this page is in", "page communities",
                "groups", "nhóm", "your groups", "nhóm của bạn",
                "linked groups", "nhóm đã liên kết", "groups you manage",
                "groups you've joined", "nhóm đã tham gia"
        }, 0);

        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MIN_VALUE;
        for (AccessibilityNodeInfo n : matches) {
            AccessibilityNodeInfo candidate = clickableSelfOrAncestor(n);
            if (candidate == null) continue;
            String rawLabel = ((n.getText() == null ? "" : n.getText().toString()) + " "
                    + (n.getContentDescription() == null ? "" : n.getContentDescription().toString()))
                    .toLowerCase(Locale.US);
            boolean pageSpecific = rawLabel.contains("nhóm của trang")
                    || rawLabel.contains("groups of this page")
                    || rawLabel.contains("page groups")
                    || rawLabel.contains("groups for this page")
                    || rawLabel.contains("groups managed by this page")
                    || rawLabel.contains("groups this page joined")
                    || rawLabel.contains("page communities");
            if (!pageSpecific && !pageIdentityStrong) {
                try { candidate.recycle(); } catch (Throwable ignored) {}
                continue;
            }
            int score = pageSpecific ? 10000 : 2500;
            if (!pageSpecific && !pageName.isEmpty() && subtreeContainsText(candidate, pageName, 8)) score += 3000;
            try {
                android.graphics.Rect r = new android.graphics.Rect();
                candidate.getBoundsInScreen(r);
                score += Math.min(2000, Math.max(0, r.top));
            } catch (Throwable ignored) {}
            if (best == null || score > bestScore) {
                if (best != null) try { best.recycle(); } catch (Throwable ignored) {}
                best = candidate;
                bestScore = score;
            } else {
                try { candidate.recycle(); } catch (Throwable ignored) {}
            }
        }
        for (AccessibilityNodeInfo n : matches) try { n.recycle(); } catch (Throwable ignored) {}
        if (best != null) {
            groupContextWasPageSpecific = true;
            return best;
        }

        // Generic label is allowed only when the clickable subtree is clearly
        // tied to the current Page. This is the safety barrier against the
        // personal profile's global Groups page.
        if (!pageName.isEmpty() && pageIdentityStrong) {
            matches.clear();
            collectContainingNodes(root, matches, new String[]{"nhóm", "groups", "group"}, 0);
            for (AccessibilityNodeInfo n : matches) {
                AccessibilityNodeInfo candidate = clickableSelfOrAncestor(n);
                if (candidate == null) continue;
                if (!subtreeContainsText(candidate, pageName, 10)) {
                    try { candidate.recycle(); } catch (Throwable ignored) {}
                    continue;
                }
                int score = 5000;
                try {
                    android.graphics.Rect r = new android.graphics.Rect();
                    candidate.getBoundsInScreen(r);
                    score += Math.min(2000, Math.max(0, r.top));
                } catch (Throwable ignored) {}
                if (best == null || score > bestScore) {
                    if (best != null) try { best.recycle(); } catch (Throwable ignored) {}
                    best = candidate;
                    bestScore = score;
                } else {
                    try { candidate.recycle(); } catch (Throwable ignored) {}
                }
            }
            for (AccessibilityNodeInfo n : matches) try { n.recycle(); } catch (Throwable ignored) {}
        }
        if (best != null) groupContextWasPageSpecific = false;
        return best;
    }

    private AccessibilityNodeInfo findBestMoreTarget(AccessibilityNodeInfo root) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> matches = new ArrayList<>();
        collectContainingNodes(root, matches, new String[]{
                "xem thêm", "see more", "more tabs", "more", "thêm", "xem tất cả", "see all"
        }, 0);

        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MIN_VALUE;
        for (AccessibilityNodeInfo n : matches) {
            AccessibilityNodeInfo candidate = clickableSelfOrAncestor(n);
            if (candidate == null) continue;
            int score = 0;
            if (!pageName.isEmpty() && subtreeContainsText(candidate, pageName, 8)) score += 5000;
            try {
                android.graphics.Rect r = new android.graphics.Rect();
                candidate.getBoundsInScreen(r);
                if (r.top > 150) score += Math.min(r.top, 1500);
            } catch (Throwable ignored) {}
            if (score > bestScore) {
                if (best != null) try { best.recycle(); } catch (Throwable ignored) {}
                best = candidate;
                bestScore = score;
            } else {
                try { candidate.recycle(); } catch (Throwable ignored) {}
            }
        }
        for (AccessibilityNodeInfo n : matches) try { n.recycle(); } catch (Throwable ignored) {}
        return best;
    }

    private boolean isPageGroupsContext(AccessibilityNodeInfo root) {
        if (root == null || !groupDiscoveryOwner.equals("PAGE")) return false;

        ArrayList<String> texts = new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        try {
            collectUsefulNodes(root, texts, nodes, 0);
            boolean groupSignal = false;
            boolean pageSignal = pageName.isEmpty();
            boolean urlSignal = false;

            for (String raw : texts) {
                String t = cleanUiText(raw).toLowerCase(Locale.US);
                if (t.contains("groups of this page") || t.contains("page groups")
                        || t.contains("nhóm của trang") || t.contains("groups this page")
                        || t.contains("nhóm mà trang tham gia") || t.contains("page communities")) {
                    groupSignal = true;
                }
                if (t.equals("groups") || t.equals("nhóm") || t.contains("group")) {
                    groupSignal = true;
                }
                if (!pageName.isEmpty() && t.contains(pageName.toLowerCase(Locale.US))) {
                    pageSignal = true;
                }
                if (t.contains("facebook.com/groups/")) urlSignal = true;
            }

            // A verified Page-specific click is the strongest evidence. If we
            // reached the screen through that click, Facebook may omit the Page
            // name from the new heading; do not reject the trusted context.
            // Without a trusted click, require both Page and Group evidence.
            if (!groupContextTrusted || !groupSignal) return false;
            if (groupContextWasPageSpecific) return true;
            return pageSignal || urlSignal;
        } finally {
            for (AccessibilityNodeInfo n : nodes) try { n.recycle(); } catch (Throwable ignored) {}
        }
    }

    /**
     * Find a clickable node by partial text/content-description and, when
     * needed, climb to its clickable parent. Facebook's Chrome accessibility
     * tree frequently puts the label on a non-clickable child of a button.
     */
    private AccessibilityNodeInfo findClickableContaining(
            AccessibilityNodeInfo root, String[] labels, boolean preferLowerContent) {

        if (root == null || labels == null) return null;

        ArrayList<AccessibilityNodeInfo> matches = new ArrayList<>();
        collectContainingNodes(root, matches, labels, 0);

        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MIN_VALUE;

        for (AccessibilityNodeInfo n : matches) {
            if (n == null) continue;

            AccessibilityNodeInfo candidate = clickableSelfOrAncestor(n);
            if (candidate == null) continue;

            int score = 0;
            String t = n.getText() == null ? "" : cleanUiText(n.getText().toString()).toLowerCase(Locale.US);
            String d = n.getContentDescription() == null ? "" :
                    cleanUiText(n.getContentDescription().toString()).toLowerCase(Locale.US);

            if (t.contains("nhóm của trang") || d.contains("nhóm của trang")
                    || t.contains("groups of this page") || d.contains("groups of this page")
                    || t.contains("page groups") || d.contains("page groups")) {
                score += 10000;
            } else if (!pageName.isEmpty() && subtreeContainsText(candidate, pageName, 5)) {
                score += 5000;
            } else if (t.equals("nhóm") || d.equals("nhóm")
                    || t.equals("groups") || d.equals("groups")) {
                score += 1000;
            }

            if (preferLowerContent) {
                try {
                    android.graphics.Rect r = new android.graphics.Rect();
                    candidate.getBoundsInScreen(r);
                    // Avoid the fixed Facebook top navigation row when a
                    // Page-specific Groups control exists lower in content.
                    if (r.top > 180) score += Math.min(r.top, 1500);
                    else score -= 500;
                } catch (Throwable ignored) {}
            }

            if (score > bestScore) {
                if (best != null) try { best.recycle(); } catch (Throwable ignored) {}
                best = candidate;
                bestScore = score;
            } else {
                try { candidate.recycle(); } catch (Throwable ignored) {}
            }
        }

        for (AccessibilityNodeInfo n : matches) {
            try { n.recycle(); } catch (Throwable ignored) {}
        }

        return best;
    }

    private boolean subtreeContainsText(AccessibilityNodeInfo node, String wanted, int depth) {
        if (node == null || wanted == null || wanted.trim().isEmpty() || depth > 5) return false;
        try {
            String w = cleanUiText(wanted).toLowerCase(Locale.US);
            String t = node.getText() == null ? "" :
                    cleanUiText(node.getText().toString()).toLowerCase(Locale.US);
            String d = node.getContentDescription() == null ? "" :
                    cleanUiText(node.getContentDescription().toString()).toLowerCase(Locale.US);

            if (t.contains(w) || d.contains(w)) return true;

            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo c = null;
                try {
                    c = node.getChild(i);
                    if (c != null && subtreeContainsText(c, wanted, depth + 1)) return true;
                } catch (Throwable ignored) {
                } finally {
                    if (c != null) try { c.recycle(); } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private void collectContainingNodes(AccessibilityNodeInfo node,
                                        ArrayList<AccessibilityNodeInfo> out,
                                        String[] labels, int depth) {
        if (node == null || out == null || depth > 40 || out.size() > 200) return;

        try {
            String t = node.getText() == null ? "" :
                    cleanUiText(node.getText().toString()).toLowerCase(Locale.US);
            String d = node.getContentDescription() == null ? "" :
                    cleanUiText(node.getContentDescription().toString()).toLowerCase(Locale.US);

            boolean match = false;
            for (String label : labels) {
                if (label == null) continue;
                String l = label.toLowerCase(Locale.US);
                if (t.contains(l) || d.contains(l)) {
                    match = true;
                    break;
                }
            }

            if (match) out.add(AccessibilityNodeInfo.obtain(node));

            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo c = null;
                try {
                    c = node.getChild(i);
                    if (c != null) collectContainingNodes(c, out, labels, depth + 1);
                } catch (Throwable ignored) {
                } finally {
                    if (c != null) try { c.recycle(); } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}
    }

    private AccessibilityNodeInfo clickableSelfOrAncestor(AccessibilityNodeInfo node) {
        if (node == null) return null;

        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(node);
        try {
            for (int depth = 0; current != null && depth < 8; depth++) {
                if (current.isClickable()) {
                    AccessibilityNodeInfo out = AccessibilityNodeInfo.obtain(current);
                    try { current.recycle(); } catch (Throwable ignored) {}
                    return out;
                }

                AccessibilityNodeInfo parent = null;
                try { parent = current.getParent(); } catch (Throwable ignored) {}
                try { current.recycle(); } catch (Throwable ignored) {}
                current = parent;
            }
        } catch (Throwable ignored) {
            if (current != null) try { current.recycle(); } catch (Throwable ignored2) {}
        }
        return null;
    }

    private void collectGroupsFromFacebookScreen(final int pass) {
        if (!isRunning || !isChromeActive() || groupDiscoveryOwner.isEmpty()) {
            groupDiscoveryRunning = false;
            return;
        }

        AccessibilityNodeInfo root = null;
        int before = discoveredGroups.size();
        try {
            root = getRootInActiveWindow();
            if (root == null || !CHROME.equals(packageName(root))) {
                if (pass < 15) {
                    handler.postDelayed(() -> collectGroupsFromFacebookScreen(pass + 1), 700L);
                } else {
                    groupDiscoveryRunning = false;
                }
                return;
            }

            boolean validContext = groupDiscoveryOwner.equals("PAGE")
                    ? isPageGroupsContext(root)
                    : isProfileGroupsContext(root);

            if (!validContext) {
                if (groupContextTrusted && pass < 4) {
                    handler.postDelayed(() -> collectGroupsFromFacebookScreen(pass + 1), 700L);
                    return;
                }
                try { performGlobalAction(GLOBAL_ACTION_BACK); } catch (Throwable ignored) {}
                groupContextTrusted = false;
                groupContextWasPageSpecific = false;
                if (groupDiscoveryOwner.equals("PAGE")) {
                    handler.postDelayed(() -> autoOpenAndCollectPageGroups(0), 900L);
                } else {
                    handler.postDelayed(() -> autoOpenAndCollectProfileGroups(0), 900L);
                }
                return;
            }

            collectGroupEntriesFromTree(root);
            updateVisibleGroupsFromDiscovered();

            int after = discoveredGroups.size();
            boolean changed = after > before;
            boolean scrolled = performScrollForward(root);

            String signature = buildGroupTreeSignature(root);
            boolean sameTree = signature.equals(lastGroupTreeSignature) && !signature.isEmpty();
            lastGroupTreeSignature = signature;

            if (changed || scrolled || !sameTree) {
                groupDiscoveryNoProgress = 0;
            } else {
                groupDiscoveryNoProgress++;
            }

            // 80 passes handles long/lazy-loaded lists. Three consecutive
            // no-progress passes with no scroll stop the state machine.
            if (pass < 80 && groupDiscoveryNoProgress < 3) {
                handler.postDelayed(() -> collectGroupsFromFacebookScreen(pass + 1), 700L);
                return;
            }

            // Return to the original Page and re-inspect it so Page state stays
            // synchronized after harvesting.
            try { performGlobalAction(GLOBAL_ACTION_BACK); } catch (Throwable ignored) {}
            groupContextTrusted = false;
            groupContextWasPageSpecific = false;
            groupDiscoveryRunning = false;
            groupDiscoveryPass = 0;
            groupDiscoveryNoProgress = 0;
            lastGroupTreeSignature = "";
            handler.postDelayed(this::inspectCurrentChromeAgain, 900L);

        } catch (Throwable ignored) {
            groupDiscoveryRunning = false;
        } finally {
            if (root != null) try { root.recycle(); } catch (Throwable ignored) {}
        }
    }

    private String buildGroupTreeSignature(AccessibilityNodeInfo root) {
        if (root == null) return "";
        ArrayList<String> texts = new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        try {
            collectUsefulNodes(root, texts, nodes, 0);
            StringBuilder b = new StringBuilder();
            int count = 0;
            for (String t : texts) {
                String s = cleanUiText(t);
                if (s.length() < 2) continue;
                b.append(s.toLowerCase(Locale.US)).append('|');
                if (++count >= 250) break;
            }
            return Integer.toHexString(b.toString().hashCode());
        } finally {
            for (AccessibilityNodeInfo n : nodes) try { n.recycle(); } catch (Throwable ignored) {}
        }
    }

    private boolean isGroupsContext(AccessibilityNodeInfo root) {
        if (root == null) return false;
        ArrayList<String> texts = new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        try {
            collectUsefulNodes(root, texts, nodes, 0);
            for (String raw : texts) {
                String t = cleanUiText(raw).toLowerCase(Locale.US);
                if (t.equals("groups") || t.equals("nhóm")
                        || t.contains("groups you've joined")
                        || t.contains("nhóm đã tham gia")
                        || t.contains("groups of this page")
                        || t.contains("nhóm của trang")
                        || t.contains("/groups/")) {
                    return true;
                }
            }
        } finally {
            for (AccessibilityNodeInfo n : nodes) try { n.recycle(); } catch (Throwable ignored) {}
        }
        return false;
    }

    /**
     * Extract every genuine /groups/... URL and useful clickable Group label
     * exposed by the current Accessibility tree.
     */
    private void collectGroupEntriesFromTree(AccessibilityNodeInfo root) {
        if (root == null) return;

        ArrayList<String> texts = new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();

        try {
            collectUsefulNodes(root, texts, nodes, 0);

            for (AccessibilityNodeInfo n : nodes) {
                String txt = n.getText() == null ? "" : cleanUiText(n.getText().toString());
                String desc = n.getContentDescription() == null ? "" :
                        cleanUiText(n.getContentDescription().toString());

                String combined = txt + " " + desc;
                String url = extractFacebookGroupUrl(combined);

                if (!url.isEmpty()) {
                    String name = txt.isEmpty() ? desc : txt;
                    name = normalizeGroupName(name);
                    if (name.isEmpty()) name = "Facebook Group";
                    discoveredGroups.put(url, name);
                }
            }

            // When href is hidden by Chrome, use clickable card labels only
            // inside a trusted Groups screen. Reject navigation/action labels
            // so the Panel does not receive buttons as fake Groups.
            if (groupContextTrusted && isGroupsContext(root)) {
                for (AccessibilityNodeInfo n : nodes) {
                    if (!n.isClickable()) continue;

                    String txt = n.getText() == null ? "" :
                            normalizeGroupName(n.getText().toString());
                    String desc = n.getContentDescription() == null ? "" :
                            normalizeGroupName(n.getContentDescription().toString());

                    String name = txt.isEmpty() ? desc : txt;
                    if (!looksLikeGroupName(name)) continue;
                    if (isGroupNavigationNoise(name)) continue;

                    String key = "name:" + name.toLowerCase(Locale.US);
                    discoveredGroups.put(key, name);
                }
            }
        } finally {
            for (AccessibilityNodeInfo n : nodes) {
                try { n.recycle(); } catch (Throwable ignored) {}
            }
        }
    }

    private String normalizeGroupName(String value) {
        if (value == null) return "";
        String s = cleanUiText(value);

        // Strip common accessibility prefixes around a group link.
        s = s.replaceFirst("(?i)^(?:group|nhóm)\\s*[:\\-]\\s*", "");
        s = s.replaceFirst("(?i)^(?:visit|xem)\\s+(?:group|nhóm)\\s*", "");
        return cleanUiText(s);
    }

    private void updateVisibleGroupsFromDiscovered() {
        String old = visibleGroupsJson;

        try {
            JSONArray a = new JSONArray();

            for (Map.Entry<String,String> e : discoveredGroups.entrySet()) {
                JSONObject o = new JSONObject();
                String key = e.getKey();
                String name = e.getValue();

                if (key.startsWith("name:")) {
                    o.put("url", "");
                    o.put("name", name);
                } else {
                    o.put("url", key);
                    o.put("name", name);
                }

                a.put(o);
            }

            visibleGroupsJson = a.toString();
        } catch (Throwable ignored) {
            return;
        }

        if (!visibleGroupsJson.equals(old)) {
            // Do not wait for the 15-second heartbeat. Panel should receive
            // the Group list as soon as Facebook exposes a new card.
            new Thread(new Runnable() {
                @Override public void run() {
                    AgentSync.heartbeat(PostFlowAccessibilityService.this);
                }
            }, "PostFlowGroupSync").start();
        }
    }

        private void inspectCurrentChromeAgain() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && CHROME.equals(packageName(root))) {
                inspectFacebookContext(root);
                String url = findChromeUrlBar(root);
                if (!url.isEmpty()) updateChromeUrl(url);
                try { root.recycle(); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    private boolean looksLikeGroupName(String value) {
        if (value == null) return false;
        String s = cleanUiText(value);
        if (s.length() < 3 || s.length() > 180) return false;
        String l = s.toLowerCase(Locale.US);
        String[] bad = {"groups", "nhóm", "group", "menu", "home", "feed",
                "search", "facebook", "notifications", "reels", "video",
                "photos", "bài viết", "ảnh", "video", "xem thêm", "see more",
                "tham gia", "join", "rời nhóm", "leave group", "mời", "invite"};
        for (String b : bad) if (l.equals(b)) return false;
        if (l.contains("http://") || l.contains("https://")) return false;
        if (l.matches(".*\\b(?:giờ|phút|hour|minutes|likes?|members?)\\b.*") && s.length() < 25) return false;
        return true;
    }

    private boolean isGroupNavigationNoise(String value) {
        if (value == null) return true;
        String l = cleanUiText(value).toLowerCase(Locale.US);
        String[] noise = {"groups", "nhóm", "group", "home", "feed", "search",
                "menu", "more", "xem thêm", "see more", "see all",
                "xem tất cả", "notifications", "reels", "photos", "video",
                "settings", "members", "thành viên", "invite", "mời",
                "join", "tham gia", "leave", "rời nhóm"};
        for (String n : noise) if (l.equals(n)) return true;
        return false;
    }

    private AccessibilityNodeInfo chooseNavigationGroupNode(ArrayList<AccessibilityNodeInfo> nodes) {
        if (nodes == null) return null;
        for (AccessibilityNodeInfo n : nodes) {
            if (n == null || !n.isClickable()) continue;
            String t = n.getText() == null ? "" : cleanUiText(n.getText().toString()).toLowerCase(Locale.US);
            String d = n.getContentDescription() == null ? "" : cleanUiText(n.getContentDescription().toString()).toLowerCase(Locale.US);
            if (isGroupsNavigationLabel(t) || isGroupsNavigationLabel(d)) return AccessibilityNodeInfo.obtain(n);
        }
        return null;
    }

    private boolean isGroupsNavigationLabel(String s) {
        if (s == null || s.isEmpty()) return false;
        return s.equals("nhóm") || s.equals("groups") || s.equals("group")
                || s.equals("nhóm của trang") || s.equals("groups of this page")
                || s.equals("page groups") || s.equals("nhóm của bạn")
                || s.equals("groups you've joined") || s.equals("groups you manage")
                || s.equals("nhóm bạn quản lý") || s.equals("nhóm đã tham gia");
    }

    private AccessibilityNodeInfo findExactClickableText(AccessibilityNodeInfo root, String[] labels) {
        if (root == null || labels == null) return null;
        ArrayList<AccessibilityNodeInfo> found = new ArrayList<>();
        collectNodesMatchingText(root, found, labels, 0);
        AccessibilityNodeInfo out = chooseFirstClickable(found);
        for (AccessibilityNodeInfo n : found) try { n.recycle(); } catch (Throwable ignored) {}
        return out;
    }

    private AccessibilityNodeInfo chooseFirstClickable(ArrayList<AccessibilityNodeInfo> nodes) {
        if (nodes == null) return null;
        for (AccessibilityNodeInfo n : nodes) {
            if (n != null && n.isClickable()) return AccessibilityNodeInfo.obtain(n);
        }
        return null;
    }

    private void collectNodesMatchingText(AccessibilityNodeInfo node, ArrayList<AccessibilityNodeInfo> out,
                                          String[] labels, int depth) {
        if (node == null || out == null || depth > 35 || out.size() > 100) return;
        try {
            String t = node.getText() == null ? "" : cleanUiText(node.getText().toString()).toLowerCase(Locale.US);
            String d = node.getContentDescription() == null ? "" : cleanUiText(node.getContentDescription().toString()).toLowerCase(Locale.US);
            for (String label : labels) {
                String l = label.toLowerCase(Locale.US);
                if (t.equals(l) || d.equals(l)) {
                    out.add(AccessibilityNodeInfo.obtain(node));
                    break;
                }
            }
            for (int i=0;i<node.getChildCount();i++) {
                AccessibilityNodeInfo c = null;
                try { c = node.getChild(i); if (c != null) collectNodesMatchingText(c,out,labels,depth+1); }
                catch (Throwable ignored) {}
                finally { if (c != null) try { c.recycle(); } catch (Throwable ignored) {} }
            }
        } catch (Throwable ignored) {}
    }

    private boolean performScrollForward(AccessibilityNodeInfo root) {
        if (root == null) return false;
        try {
            if (root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return true;
        } catch (Throwable ignored) {}
        return findAndScrollNode(root, 0);
    }

    private boolean findAndScrollNode(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 35) return false;
        try {
            if (node.isScrollable() && node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return true;
            for (int i=0;i<node.getChildCount();i++) {
                AccessibilityNodeInfo c=null;
                try { c=node.getChild(i); if(c!=null && findAndScrollNode(c,depth+1)) return true; }
                catch(Throwable ignored) {}
                finally { if(c!=null) try{c.recycle();}catch(Throwable ignored){} }
            }
        } catch(Throwable ignored) {}
        return false;
    }

    private void collectUsefulNodes(AccessibilityNodeInfo node, ArrayList<String> texts,
                                    ArrayList<AccessibilityNodeInfo> nodes, int depth) {
        if (node == null || depth > 35 || texts.size() > 1200) return;
        try {
            String t = node.getText() == null ? "" : node.getText().toString().trim();
            String d = node.getContentDescription() == null ? "" : node.getContentDescription().toString().trim();
            if (!t.isEmpty()) texts.add(t);
            if (!d.isEmpty()) texts.add(d);
            if (!t.isEmpty() || !d.isEmpty()) nodes.add(AccessibilityNodeInfo.obtain(node));
            int count = node.getChildCount();
            for (int i=0;i<count;i++) {
                AccessibilityNodeInfo c=null;
                try { c=node.getChild(i); if(c!=null) collectUsefulNodes(c,texts,nodes,depth+1); }
                catch(Throwable ignored) {}
                finally { if(c!=null) try{c.recycle();}catch(Throwable ignored){} }
            }
        } catch(Throwable ignored) {}
    }

    /**
     * Infer the currently selected Facebook Page from the mobile composer and
     * Page UI.  Facebook frequently renders the Page name next to the
     * "What's on your mind?" composer even though the omnibox remains
     * facebook.com.  This is intentionally UI-only; no cookies/passwords are
     * accessed.
     */
    private boolean isFacebookDocumentTree(ArrayList<String> texts, String currentUrl) {
        if (isFacebookUrl(currentUrl)) return true;
        if (texts == null) return false;

        int strong = 0;
        int facebookWord = 0;
        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw).toLowerCase(Locale.US);
            if (s.contains("facebook.com") || s.equals("facebook") || s.contains("facebook ")) facebookWord++;
            if (s.contains("bạn đang nghĩ gì") || s.contains("ban dang nghi gi")
                    || s.contains("what's on your mind") || s.contains("what’s on your mind")) strong++;
            if (s.equals("bảng tin") || s.equals("news feed") || s.equals("feed")
                    || s.equals("reels") || s.equals("marketplace") || s.equals("friends")
                    || s.equals("bạn bè") || s.equals("notifications") || s.equals("thông báo")
                    || s.equals("groups") || s.equals("nhóm")) strong++;
            if (s.contains("professional dashboard") || s.contains("bảng điều khiển chuyên nghiệp")
                    || s.contains("using facebook as") || s.contains("đang sử dụng facebook với tư cách")
                    || s.contains("switch to a page") || s.contains("chuyển sang trang")) strong += 2;
        }
        return strong >= 2 && (facebookWord > 0 || strong >= 4);
    }

    private boolean hasStrongPersonalIdentitySignal(ArrayList<String> texts) {
        if (texts == null) return false;
        boolean explicitProfile = false;
        boolean profileNavigation = false;
        boolean personalControls = false;

        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw).toLowerCase(Locale.US);

            if (s.contains("trang cá nhân") || s.contains("trang ca nhan")
                    || s.contains("your profile") || s.contains("my profile")
                    || s.contains("personal profile") || s.contains("chỉnh sửa trang cá nhân")
                    || s.contains("chinh sua trang ca nhan") || s.contains("edit profile")
                    || s.contains("switch to profile") || s.contains("chuyển sang trang cá nhân")) {
                explicitProfile = true;
            }
            if (s.equals("bạn bè") || s.equals("ban be") || s.equals("friends")
                    || s.equals("bài viết") || s.equals("bai viet")
                    || s.equals("posts") || s.equals("about") || s.equals("giới thiệu")) {
                profileNavigation = true;
            }
            if (s.contains("add story") || s.contains("thêm tin") || s.contains("them tin")
                    || s.contains("edit public details") || s.contains("chỉnh sửa chi tiết công khai")) {
                personalControls = true;
            }
        }

        return explicitProfile || (profileNavigation && personalControls);
    }

    private boolean hasStrongPageIdentitySignal(ArrayList<String> texts, String inferred, String detected) {
        if (texts == null) return false;
        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw).toLowerCase(Locale.US);
            if (s.contains("đang sử dụng facebook với tư cách")
                    || s.contains("đang dùng facebook với tư cách")
                    || s.contains("using facebook as")
                    || s.contains("switch to a page")
                    || s.contains("chuyển sang trang")
                    || s.contains("professional dashboard")
                    || s.contains("bảng điều khiển chuyên nghiệp")) return true;
        }
        // The Page composer is a strong practical signal when it is paired
        // with a real Page name; it is much safer than accepting a bare
        // occurrence of the word "Page".
        return !inferred.isEmpty() && !detected.isEmpty();
    }

    private String inferPageNameFromFacebookUi(ArrayList<String> texts) {
        if (texts == null) return "";

        String[] patterns = {
                "(?i)^(.{2,120})\\s+(?:ơi,?\\s*)?(?:bạn đang nghĩ gì|ban dang nghi gi).*$",
                "(?i)^(.{2,120})\\s+(?:ơi,?\\s*)?(?:what(?:'|’)s on your mind).*$",
                "(?i)^(.{2,120})\\s+(?:đang nghĩ gì|dang nghi gi).*$",
                "(?i).*?(?:page|trang)\\s*[:\\-]\\s*(.{2,120})$",
                "(?i).*?(?:professional dashboard|bảng điều khiển chuyên nghiệp)\\s*[:\\-]?\\s*(.{2,120})$"
        };

        for (String raw : texts) {
            if (raw == null) continue;
            String s = cleanUiText(raw);
            if (s.length() < 3 || s.length() > 220) continue;

            for (String pattern : patterns) {
                try {
                    java.util.regex.Matcher m = Pattern.compile(pattern).matcher(s);
                    if (m.matches()) {
                        String candidate = cleanUiText(m.group(1));
                        candidate = candidate.replaceFirst(
                                "(?i)^(?:bài viết|bài viết của|post|page)\\s*[:\\-]\\s*", "");
                        if (isPlausiblePageName(candidate)) return candidate;
                    }
                } catch (Throwable ignored) {}
            }
        }

        // Common Facebook Page composer wording can be exposed as separate
        // nodes. Look for a short name immediately before/after the composer.
        for (int i = 0; i < texts.size(); i++) {
            String t = cleanUiText(texts.get(i));
            String lower = t.toLowerCase(Locale.US);
            if (lower.contains("bạn đang nghĩ gì") || lower.contains("ban dang nghi gi")
                    || lower.contains("what's on your mind") || lower.contains("what’s on your mind")) {
                for (int j = Math.max(0, i - 3); j <= Math.min(texts.size() - 1, i + 3); j++) {
                    String candidate = cleanUiText(texts.get(j));
                    if (!candidate.equals(t) && isPlausiblePageName(candidate)) {
                        return candidate;
                    }
                }
            }
        }
        return "";
    }

    private boolean isPlausiblePageName(String value) {
        if (value == null) return false;
        String s = cleanUiText(value);
        if (s.length() < 2 || s.length() > 120) return false;

        String l = s.toLowerCase(Locale.US);
        String[] bad = {
                "facebook", "trang", "page", "bài viết", "bai viet",
                "home", "feed", "reels", "video", "photos", "menu",
                "bạn đang nghĩ gì", "ban dang nghi gi", "what's on your mind"
        };
        for (String b : bad) if (l.equals(b)) return false;

        if (s.matches("(?i)^https?://.*$")) return false;
        if (s.matches(".*\\b(?:giờ|phút|hour|minutes)\\b.*")) return false;
        return true;
    }

    private String extractPageName(String raw) {
        if (raw == null) return "";
        String s = cleanUiText(raw);
        String[] patterns = {
            "(?i).*?(?:đang sử dụng facebook với tư cách|đang dùng facebook với tư cách|sử dụng facebook với tư cách|dùng facebook với tư cách)[:\\s]+(.+)$",
            "(?i).*?(?:switch(?:ed)? to|using facebook as|continue as)[:\\s]+(.+)$",
            "(?i).*?(?:trang hiện tại|page hiện tại|current page)[:\\s]+(.+)$"
        };
        for (String p : patterns) {
            java.util.regex.Matcher m=Pattern.compile(p).matcher(s);
            if(m.matches()) return cleanUiText(m.group(1));
        }
        return "";
    }

    private int pageNameScore(String raw, String name) {
        String s=raw.toLowerCase(Locale.US);
        int score=0;
        if(s.contains("đang sử dụng facebook với tư cách") || s.contains("đang dùng facebook với tư cách")) score+=100;
        if(s.contains("using facebook as") || s.contains("switch to")) score+=90;
        if(s.contains("trang hiện tại") || s.contains("page hiện tại")) score+=80;
        if(name.length()>=2 && name.length()<=120) score+=10;
        return score;
    }

    private boolean containsPageContextSignal(ArrayList<String> texts) {
        for(String t:texts){
            String s=t.toLowerCase(Locale.US);
            if(s.contains("đang sử dụng facebook với tư cách") || s.contains("đang dùng facebook với tư cách")
                || s.contains("using facebook as") || s.contains("switch to a page")
                || s.equals("trang") || s.equals("pages")) return true;
        }
        return false;
    }

    private String extractFacebookGroupUrl(String raw) {
        if(raw==null) return "";
        java.util.regex.Matcher m=Pattern.compile("(?i)(https?://(?:www\\.)?facebook\\.com/groups/[a-zA-Z0-9._-]+(?:/[^\\s\\]\\)<>]*)?)").matcher(raw);
        return m.find() ? m.group(1).replaceAll("[.,;]+$","") : "";
    }

    private String cleanUiText(String s){
        if(s==null) return "";
        return s.replaceAll("\\s+"," ").trim();
    }

    private String extractPageId(ArrayList<String> texts, String... urls) {
        try {
            Pattern p = Pattern.compile("(?i)(?:page\\s*(?:id|identifier)|id\\s*trang|id\\s*page)\\s*[:#]?\\s*(\\d{5,30})");
            for (String t : texts) {
                if (t == null) continue;
                java.util.regex.Matcher m = p.matcher(t);
                if (m.find()) return m.group(1);
            }
            Pattern u = Pattern.compile("(?i)/pages/[^/]+/(\\d{5,30})(?:/|$)");
            Pattern q = Pattern.compile("(?i)[?&](?:id|page_id)=(\\d{5,30})(?:&|$)");
            for (String url : urls) {
                if (url == null) continue;
                java.util.regex.Matcher m = u.matcher(url);
                if (m.find()) return m.group(1);
                m = q.matcher(url);
                if (m.find()) return m.group(1);
            }

            // Some Facebook accessibility nodes expose complete href-like
            // strings even when the omnibox is only facebook.com.
            for (String t : texts) {
                if (t == null) continue;
                java.util.regex.Matcher m = u.matcher(t);
                if (m.find()) return m.group(1);
                m = q.matcher(t);
                if (m.find()) return m.group(1);
            }
        } catch (Throwable ignored) {}
        return "";
    }

    private void savePageId(String value){
        try{ getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(PREF_LAST_PAGE_ID,value).apply(); }catch(Throwable ignored){}
    }
    private String getSavedPageId(){
        try{return getSharedPreferences(PREFS,MODE_PRIVATE).getString(PREF_LAST_PAGE_ID,"");}catch(Throwable ignored){return "";}
    }

    private void savePageName(String value){
        try{ getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(PREF_LAST_PAGE_NAME,value).apply(); }catch(Throwable ignored){}
    }
    private String getSavedPageName(){
        try{return getSharedPreferences(PREFS,MODE_PRIVATE).getString(PREF_LAST_PAGE_NAME,"");}catch(Throwable ignored){return "";}
    }

    private void updateChromeUrl(String value) {
        String url = normalizeUrl(value);

        if (url.isEmpty()) return;

        /*
         * Facebook mobile can briefly expose /login/identify, /home, /
         * or another shell URL while the already-rendered Page remains on
         * screen. Never destroy a previously captured specific Page URL with
         * one of these generic Facebook routes.
         */
        if (isFacebookUrl(url) && isGenericFacebookRoute(url)) {
            String saved = getSavedPageUrl();
            if (isSpecificPageUrl(saved)) {
                url = saved;
            } else if (isSpecificPageUrl(lastUrl)) {
                url = lastUrl;
            }
        }

        boolean changed = !url.equals(lastUrl)
                || facebookDetected != isFacebookUrl(url);

        long now = System.currentTimeMillis();
        beginOrKeepChromeSession(now);

        lastPackage = CHROME;
        lastUrl = url;
        lastChromeTime = now;

        // IMPORTANT: Once Facebook has been detected in this Chrome session,
        // changing to another Chrome tab must NOT make Facebook disappear.
        // It is cleared only when a genuinely new Chrome session starts.
        if (isFacebookUrl(url)) {
            facebookSeenInChromeSession = true;
        }
        facebookDetected = facebookSeenInChromeSession;

        if (isSpecificPageUrl(url)) {
            pageUrl = url;
            savePageUrl(url);
        }

        // Push a changed Chrome/Facebook URL immediately. The regular
        // heartbeat remains as a fallback, but navigation should not wait
        // 15 seconds before Panel sees the new Facebook Page URL.
        if (changed) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    AgentSync.heartbeat(PostFlowAccessibilityService.this);
                }
            }, "PostFlowUrlSync").start();
        }
    }

    private boolean isGenericFacebookRoute(String value) {
        try {
            android.net.Uri uri = android.net.Uri.parse(value);
            String path = uri.getPath() == null ? "" : uri.getPath().trim();
            String first = path.replaceFirst("^/", "").split("/", 2)[0].toLowerCase(Locale.US);
            return first.isEmpty()
                    || "login".equals(first)
                    || "recover".equals(first)
                    || "home".equals(first)
                    || "watch".equals(first)
                    || "reels".equals(first)
                    || "groups".equals(first)
                    || "pages".equals(first)
                    || "messages".equals(first)
                    || "notifications".equals(first)
                    || "friends".equals(first)
                    || "settings".equals(first)
                    || "search".equals(first)
                    || "marketplace".equals(first);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean isSpecificPageUrl(String value) {
        if (!isFacebookUrl(value)) return false;
        try {
            android.net.Uri uri = android.net.Uri.parse(value);
            String path = uri.getPath() == null ? "" : uri.getPath().trim();
            if (path.isEmpty() || "/".equals(path)) return false;
            String clean = path.replaceFirst("^/", "");
            String first = clean.split("/", 2)[0].toLowerCase(Locale.US);
            if ("groups".equals(first) || "login".equals(first) || "recover".equals(first)
                    || "home".equals(first) || "watch".equals(first) || "reels".equals(first)
                    || "videos".equals(first) || "marketplace".equals(first) || "events".equals(first)
                    || "gaming".equals(first) || "messages".equals(first) || "notifications".equals(first)
                    || "friends".equals(first) || "settings".equals(first) || "search".equals(first)) return false;
            return clean.matches("(?i)^(?:pages/[^/]+(?:/[0-9]+)?|pg/[^/]+|profile\\.php(?:/|$)|[^/]+(?:/.*)?)$");
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void savePageUrl(String url) {
        try {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(PREF_LAST_PAGE_URL, url)
                    .apply();
        } catch (Throwable ignored) {}
    }

    private String getSavedPageUrl() {
        try {
            return getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(PREF_LAST_PAGE_URL, "");
        } catch (Throwable ignored) {
            return "";
        }
    }

    private String normalizeUrl(String value) {
        if (value == null) return "";

        String s = value.trim();

        if (s.isEmpty()) return "";

        if (!s.matches("(?i)^https?://.*")) {
            if (s.matches("(?i)^(?:www\\.)?(?:[a-z0-9-]+\\.)*facebook\\.com(?:/.*)?$")) {
                return "https://" + s;
            }
        }

        return s;
    }

    private boolean isFacebookUrl(String value) {
        if (value == null) return false;

        String s = value.trim();

        if (s.isEmpty()) return false;

        return FACEBOOK_URL.matcher(s).matches();
    }

    private void expireStaleState() {
        long now = System.currentTimeMillis();

        if (CHROME.equals(lastPackage)
                && lastChromeTime > 0
                && now - lastChromeTime > STATE_TIMEOUT_MS) {

            // Before declaring Chrome gone, inspect the currently visible
            // accessibility windows. Switching Chrome tabs or briefly leaving
            // the Agent must never clear the session.
            boolean chromeStillVisible = false;
            try {
                List<AccessibilityWindowInfo> windows = getWindows();
                if (windows != null) {
                    for (AccessibilityWindowInfo w : windows) {
                        if (w == null) continue;
                        AccessibilityNodeInfo r = null;
                        try {
                            r = w.getRoot();
                            if (r != null && CHROME.equals(packageName(r))) {
                                chromeStillVisible = true;
                                break;
                            }
                        } catch (Throwable ignored) {
                        } finally {
                            if (r != null) try { r.recycle(); } catch (Throwable ignored) {}
                        }
                    }
                }
            } catch (Throwable ignored) {}

            if (!chromeStillVisible) {
                lastPackage = "";
                lastUrl = "";
            }

            facebookDetected = facebookSeenInChromeSession;
        }
    }

    public static boolean isChromeActive() {
        long now = System.currentTimeMillis();

        return CHROME.equals(lastPackage)
                && lastChromeTime > 0
                && now - lastChromeTime <= STATE_TIMEOUT_MS;
    }

    public static boolean isFacebookActive() {
        return isChromeActive() && facebookDetected;
    }
    public static boolean isPageDetected() {
        return isChromeActive() && pageDetected;
    }

    public static String currentPageName() { return pageName == null ? "" : pageName; }
    public static String currentPageUrl() { return pageUrl == null ? "" : pageUrl; }
    public static String currentPageId() { return pageId == null ? "" : pageId; }
    public static String currentFacebookMode() { return facebookMode == null ? "UNKNOWN" : facebookMode; }
    public static String currentVisibleGroupsJson() { return visibleGroupsJson == null ? "[]" : visibleGroupsJson; }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        // Ask Android to rebind this AccessibilityService automatically if
        // the system temporarily disconnects it. Closing MainActivity must
        // NOT mean the accessibility permission is lost.
        isRunning = false;
        handler.removeCallbacks(poller);
        handler.removeCallbacks(heartbeat);
        handler.removeCallbacks(commandPoller);
        return true;
    }

    @Override
    public void onRebind(android.content.Intent intent) {
        super.onRebind(intent);
        onServiceConnected();
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(poller);
        handler.removeCallbacks(heartbeat);
        handler.removeCallbacks(commandPoller);

        isRunning = false;
        lastPackage = "";
        lastUrl = "";
        facebookDetected = false;
        facebookSeenInChromeSession = false;
        chromeSessionStartedAt = 0L;
        lastChromeTime = 0L;

        super.onDestroy();
    }
}
